import React from "react";

function Footer(){
    return(
        <footer>
            <span>
                <h3>Skapad av Jesper Jensen TE4</h3>
            </span>
        </footer>
    );
}

export default Footer;